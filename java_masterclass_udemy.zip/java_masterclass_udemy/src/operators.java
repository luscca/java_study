public class operators {
    public static void main(String[] args) {
        boolean bodyLive = false;
        float a=5, b=9, c=0, d=4, x=8, y=-4;
        c += 1;
        b -= 2;
        a *= 20;
        d /= 2;
        x--;
        y++;
        System.out.println(c + " " + b + " "+ a + " "+ d + " "+ x + " "+ y);
        if(bodyLive){System.out.println("Is alive.");} else{System.out.println("Is dead.");}
        if(c>0 && c<2){
            System.out.println("печенье");
        }
        if(a%2==1 || a/2 == 50){
            System.out.println("クッキー");
        }
        if(d<=2){
            System.out.println("バナナ");
        }
        boolean isCar = false;
        if(isCar == true){
            System.out.println("This is not supposed to happen.");
        }
        isCar = true;
        boolean wasCar = isCar ? true : false;
        if(wasCar){
            System.out.println("wasCar is true.");
        }
    }
}
