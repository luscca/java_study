public class min_and_max {
    public static void main(String[] args) {
        int myValue = 10000;
        int myMinIntValue = Integer.MIN_VALUE;
        int myMaxIntValue = Integer.MAX_VALUE;
        System.out.println("My Min Value:"+myMinIntValue);
        System.out.println("My Max Value:"+myMaxIntValue);
        System.out.println("Busted MAX value:" + (myMaxIntValue+1));
        System.out.println("Busted MIN value:" + (myMinIntValue-1));

        int myMaxIntTest = 2_147_483_647;

        byte myMinByteValue = Byte.MIN_VALUE;
        byte myMaxByteValue = Byte.MAX_VALUE;
        System.out.println("My Min Byte Value:" + myMinByteValue);
        System.out.println("My Max Byte Value:" + myMaxByteValue);

        short myMinShortValue = Short.MIN_VALUE;
        short myMaxShortValue = Short.MAX_VALUE;
        System.out.println("My Min Short Value:" + myMinShortValue);
        System.out.println("My Max Short Value:" + myMaxShortValue);

        long myLongValue = 100L;
        long myMinlongValue = Long.MIN_VALUE;
        long myMaxlongValue = Long.MAX_VALUE;
        System.out.println("Long Min Value:" + myMinlongValue);
        System.out.println("Long Max Value:" + myMaxlongValue);
        long bigLongLiteralValue = 2_147_483_647_234L;
        System.out.println(bigLongLiteralValue);

        short bigShortLiteralValue = 32767;

        int myTotal = (myMinIntValue / 2);
        byte myNewByte = (byte) (myMinByteValue / 2);
        short myNewShortValue = (short)(myMinShortValue / 2);
        long myNewLongValue = (long)(myLongValue / 2);
        System.out.println("Integer:" + myTotal + " Byte:" + myNewByte + " Short:" +myNewShortValue + " Long:" +myNewLongValue);

        byte byteNumber = 10;
        short shortNumber = 20;
       /* byteNumber = (byte)((byteNumber+20)/3);
        shortNumber = (short)((shortNumber-400)/2);
        System.out.println(byteNumber + " " +shortNumber); */
        int intValue = 50;
        long longValue = 50000L + 10L*(byteNumber + shortNumber + intValue);
        System.out.println(longValue);

        short shortTotal = (short)(1000 + 10*(byteNumber + shortNumber));
        System.out.println(shortTotal);

        float myMinFloatValue = Float.MIN_VALUE;
        float myMaxFloatValue = Float.MAX_VALUE;
        System.out.println("Float Minimum:" + myMinFloatValue);
        System.out.println("Float Max:" + myMaxFloatValue);
        char myCharacte = '\u00A9';
        System.out.println("Character: " +myCharacte);
        boolean bodyLive = false;
        if(bodyLive){
            System.out.println("Is active.");
        }
        else{
            System.out.println("Is inactive.");
        }

        String myNameIs = "Luccas";
        System.out.println("My name is " +myNameIs);
        myNameIs = myNameIs + ", and this is more.";;
        System.out.println("É isso ai; "+myNameIs);
        myNameIs = myNameIs + "\u00A9 2019";
        System.out.println("My Name is: " + myNameIs);

        String numberString = "3.14";;
        numberString += "598";
        System.out.println("Number in string:" + numberString);
        String lastString = "10";
        int myInt = 50;
        lastString += myInt;
        double doubleNumber = 120.47d;
        lastString += doubleNumber;
        System.out.println("LastString is equal to " + lastString);
    }
}
