import java.util.Scanner;

public class average_of_four_notes_and_hello_human {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Hello human! Welcome to the first project of Lopes in the course of Java!");
        float summation = 0;
        for (int i = 1; i <= 4; i++) {
            System.out.println(i + "º note:");
            float note = in.nextFloat();
            summation += note;
        }
        float avg = summation / 4;
        System.out.println("Average:" + avg);
    }
}